package com.ust.karate;

import com.intuit.karate.junit5.Karate;

public class KarateRunner {
	
	@Karate.Test
	public Karate runTest() {
		return Karate.run("crud.feature").relativeTo(getClass());
	}

}

