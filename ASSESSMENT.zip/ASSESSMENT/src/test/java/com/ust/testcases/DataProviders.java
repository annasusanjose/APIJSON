package com.ust.testcases;

import java.io.File;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.annotations.DataProvider;

import com.ust.utils.ExcelReader;

public class DataProviders {

	@DataProvider(name="data")
	public String[][] getpostdata() throws InvalidFormatException, IOException {
		File f = new File(System.getProperty("user.dir") + "\\src\\test\\resources\\Data Source\\New Microsoft Excel Worksheet.xlsx");
		String name = "Sheet1";
		return ExcelReader.getExcelData(f, name);
	}

}