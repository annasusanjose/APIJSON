package com.ust.testcases;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import java.io.File;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import com.ust.endpoints.UserEndPoints;
import com.ust.payloads.UserModel;
import com.ust.utils.ExtentReportListener;

import io.restassured.RestAssured;
import io.restassured.response.Response;


@Listeners(ExtentReportListener.class)
public class TestPath {

	public UserModel payload;

	
	@BeforeClass
	public void setUp() {
		payload = new UserModel(1, "foo", "bar", 1);
	}

	@Test(priority = 6)
	public void getSingleReqTest() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndPoints.getUser(payload.getId());
		response.then().log().all();
		AssertJUnit.assertEquals(response.getStatusCode(), 200);
	}

	@Test(priority = 1)
	public void getListTest() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndPoints.getListUser();
		response.then().log().all();
		AssertJUnit.assertEquals(response.getStatusCode(), 200);
	}

	@Test(priority = 2, dataProvider = "data", dataProviderClass = DataProviders.class)
	public void testPostUser(String title, String body, String userId) {
		RestAssured.useRelaxedHTTPSValidation();
		UserModel payload = new UserModel();
		payload.setTitle(title);
		payload.setBody(body);
		payload.setId(Integer.parseInt(userId));
		Response response = UserEndPoints.postReq(payload);
		response.then().log().all();
		AssertJUnit.assertEquals(response.getStatusCode(), 201);
	}

	@Test(priority = 3)
	public void putReqTest() {
		RestAssured.useRelaxedHTTPSValidation();
		UserModel payload2 = new UserModel(1, "foo", "bar", 1);
		Response response = UserEndPoints.putReq(payload.getId(), payload2);
		response.then().log().all();
		AssertJUnit.assertEquals(response.getStatusCode(), 200);
	}



	@Test(priority = 5)
	public void deleteReqTest() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndPoints.delReq(payload.getId());
		response.then().log().all();
		AssertJUnit.assertEquals(response.getStatusCode(), 200);
	}



	@Test(priority = 0)
	public void schemavalidation() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndPoints.getListUser();
		response.then().assertThat().body(matchesJsonSchema(
				new File(System.getProperty("user.dir")+"\\src\\test\\resources\\schema.json")));
	}
}
