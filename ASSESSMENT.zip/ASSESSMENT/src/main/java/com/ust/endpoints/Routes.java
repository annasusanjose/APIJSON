package com.ust.endpoints;

public class Routes {

	public static String baseuri = "https://jsonplaceholder.typicode.com";
	public static String getSingleuser = "/posts/{id}";
	public static String getList = "/posts";
	public static String postRequest = "/posts";
	public static String putRequest = "/posts/{id}";
	public static String deleteRequest = "/posts/{id}";


}

